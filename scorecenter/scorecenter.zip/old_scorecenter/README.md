Inbar Fried
Comp. 20 - Spring 2013 - Ming Chow
Assignment 5 - Scorecenter

http://infinite-basin-3622.herokuapp.com/

All aspects of the assignment have been correctly implemented to my knowledge.

People I collaborated with:
    - All posts on Piazza.
    - Stack Overflow
    - Ming Chow
    - Eric Douglas
    - Tim Alander
    - Sean Harrington
    - Dennis Chen

Hours spent on assignment:
    - 5
