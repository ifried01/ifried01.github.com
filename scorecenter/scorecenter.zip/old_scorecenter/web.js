var express = require ("express");
var mongo   = require ("mongodb");
var app = express.createServer(express.logger());
app.use(express.bodyParser());

/* include mongo */
var mongoUri = process.env.MONGOLAB_URI || 
 'mongodb://ifried01:ming@dharma.mongohq.com:10072/my_mongodb' || 
  'mongodb://localhost/my_mongodb';
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});

/* allow for cross origin reference sharing */
var allowCORS = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
     
    if('OPTIONS' == req.method) { res.send(200); }
    else { next(); }
}
app.use(allowCORS);

/* display the first 100 entries in the database as a table */
app.get('/', function(request, response) {
    var indexPage = '';
    db.collection('highscores', function(er, collection) {
        collection.find().sort({score:-1}).limit(100).toArray(function(err, cursor) {
            if (!err) {    
                indexPage += "<!DOCTYPE HTML><html><head><title>ScoreCenter</title></head><h1>ScoreCenter</h1></br>" +
                             "<table border='1'><tr><th>Username</th><th>Score</th><th>Game Title</th><th>Created At</th></tr>";
                for (var count = 0; count < cursor.length; count++) {
                    indexPage += "<tr><td>" + cursor[count].username + "</td>" + "<td>" + cursor[count].score + "</td>" + "<td>" + cursor[count].game_title + "</td>" +
                    "<td>" + cursor[count].created_at + "</td></tr>";
                }
                indexPage += "</table></body></html>"
                response.send(indexPage);
            }
            else {
                response.send("Whoops, something went wrong");
            }
        })
    })
});

/* allow the user to search for a username */
app.get("/usersearch", function (request, response) {
    response.send("<body>" +
                      "<form action='/searchresult'" + 
                      "method='get'> Username: <input type='text' name='input' id='input'>" +
                      "<input type='submit' id='submit'> </form></body>");
});

/* display the results of the usersearch */
app.get('/searchresult', function(request, response, next){
    var i = request.query['input'];
    //response.set('Content-Type', 'text/html');
    db.collection('highscores', function(er, collection) {
        collection.find({username: i}).toArray(function(err, scores){
            if(err || !scores) {
                response.send("Error: " + err);
            }
            else { response.send(scores); }
        });
    });
});

/* display the top ten highest scores for a game */
app.get("/highscores.json", function (request, response) {
    var game = request.query["game_title"]; 
    db.collection('highscores', function(er, collection) {
        collection.find({game_title: game}).sort({score: -1}).limit(10).toArray(function(err, scores){
            if(err || !scores) console.log("Could not find game title " + game);
                else{response.send(scores);}
        });
    });
});

/* recieves information from a game and stores it into the database */
app.post("/submit.json", function (request, response){
    var game_title = request.body.game_title;
    var score      = parseInt(request.body.score);
    var username   = request.body.username;
    var record = {"game_title": game_title, "username": username, "score": score, "created_at": Date()};
    db.collection('highscores', function(er, collection) {
        collection.insert(record, function(err, saved) {
            if (err) {
                response.send("Whoops, something went terribly wrong");
            }
            else if (!saved) {
                response.send("Whoops, data was not saved...");
            }
            else {
                response.send("localStorage...");
            }
        })
    });
});

/* This request should not occur */
app.get("/submit.json", function (request, response) {
    response.send("something went wrong");
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});

